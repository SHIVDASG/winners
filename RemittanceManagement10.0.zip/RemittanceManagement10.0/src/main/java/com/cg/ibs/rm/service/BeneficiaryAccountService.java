package com.cg.ibs.rm.service;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.Set;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.exception.IBSExceptions;

public interface BeneficiaryAccountService {
	public Set<Beneficiary> showBeneficiaryAccount(String uci) throws IBSExceptions;

	public boolean validateBeneficiaryAccountNumber(String accountNumber);

	public boolean validateBeneficiaryAccountNameOrBankName(String name);

	public boolean validateBeneficiaryIfscCode(String ifsc);

	public boolean modifyBeneficiaryAccountDetails(BigInteger accountNumber, Beneficiary beneficiary)
			throws IBSExceptions, SQLException, IOException;

	public boolean deleteBeneficiaryAccountDetails(BigInteger accountNumber) throws IBSExceptions;

	public boolean saveBeneficiaryAccountDetails(Beneficiary beneficiary) throws IBSExceptions;
}
