package com.cg.ibs.rm.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.IBSExceptions;

public class AutoPaymentDAOImpl implements AutoPaymentDAO {
	private static Logger LOGGER = Logger.getLogger(AutoPaymentDAOImpl.class);

	@Override
	public Set<AutoPayment> getAutopaymentDetails(String uci) throws IBSExceptions {
		LOGGER.info("entering into getAutopaymentDetails method of AutoPaymentDAOImpl class");
		Set<AutoPayment> autoPayments = new HashSet<>();
		try (PreparedStatement statement = con.prepareStatement(QueryMapper.GET_AUTOPAYMENTS);) {
			statement.setBigDecimal(1, new BigDecimal(uci));
			try (ResultSet resultSet = statement.executeQuery();) {
				while (resultSet.next()) {
					AutoPayment autoPayment = new AutoPayment();
					autoPayment.setAmount(new BigDecimal(resultSet.getString("Amount")));
					autoPayment.setDateOfStart(resultSet.getString("DateOfStart"));
					autoPayment.setServiceProviderId(new BigInteger(resultSet.getString("SPI")));
					autoPayments.add(autoPayment);
				}
			}
		} catch (SQLException exception) {
			LOGGER.error("error in QueryMapper.GET_AUTOPAYMENTS");
			throw new IBSExceptions(ExceptionMessages.ERROR11);
		}
		return autoPayments;

	}

	@Override
	public boolean copyDetails(String uci, AutoPayment autoPayment) throws IBSExceptions {
		LOGGER.info("entering into copyDetails method of AutoPaymentDAOImpl class");
		boolean check = false;
		Connection con = ConnectionProvider.getConnection();

		try (PreparedStatement statement = con.prepareStatement(QueryMapper.ADD_AUTOPAYMENTS);) {
			statement.setBigDecimal(1, (autoPayment.getAmount()));
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date = LocalDate.parse(autoPayment.getDateOfStart(), dateTimeFormatter);
			statement.setDate(2, Date.valueOf(date));
			LocalDateTime dateTime = LocalDateTime.now();
			statement.setTimestamp(3, Timestamp.valueOf(dateTime));
			statement.setBigDecimal(4, new BigDecimal(uci));
			statement.setBigDecimal(5, new BigDecimal(autoPayment.getServiceProviderId()));

			if (statement.executeUpdate() > 0) {
				check = true;
			}
		} catch (SQLException exception) {
			LOGGER.error("error in QueryMapper.ADD_AUTOPAYMENTS");
			throw new IBSExceptions(ExceptionMessages.ERROR11);
		}
		return check;
	}

	@Override
	public boolean deleteDetails(String uci, BigInteger serviceProviderId) throws IBSExceptions {
		LOGGER.info("entering into getDetails method of CreditCardDAOImpl class");
		boolean result = false;
		Connection connection = ConnectionProvider.getConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT SPI FROM AUTOPAYMENT_TABLE WHERE UCI = ? AND SPI =?");) {
			preparedStatement.setBigDecimal(1, new BigDecimal(uci));
			preparedStatement.setBigDecimal(2, new BigDecimal(serviceProviderId));
			try (ResultSet getCard = preparedStatement.executeQuery();) {
				if (getCard.next()) {
					try (PreparedStatement preparedStatement2 = connection
							.prepareStatement(QueryMapper.DELETE_AUTOPAYMENTS);) {
						preparedStatement2.setBigDecimal(1, new BigDecimal(uci));
						preparedStatement2.setBigDecimal(2,new BigDecimal(serviceProviderId));
						int check = preparedStatement2.executeUpdate();
						if (check > 0) {
							result = true;
						}
					}
				} else {
					
					throw new IBSExceptions(ExceptionMessages.ERROR6);
				}

			}
		} catch (SQLException exception) {
			exception.printStackTrace();
			LOGGER.error("error in QueryMapper.GET_CARD");
			throw new IBSExceptions(ExceptionMessages.ERROR11);
		}
		return result;
	}
	
	@Override
	public Set<ServiceProvider> showServiceProviderList() throws IBSExceptions {
		LOGGER.info("entering into showServiceProviderList method of AutoPaymentDAOImpl class");
		Set<ServiceProvider> providers = new HashSet<>();
		Connection con = ConnectionProvider.getConnection();
		try (PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.SERVICE_LIST);
				ResultSet resultSet = preparedStatement.executeQuery();) {
			while (resultSet.next()) {
				ServiceProvider provider = new ServiceProvider(
						new BigInteger(resultSet.getBigDecimal("SPI").toString()), resultSet.getString("Company_Name"));
				providers.add(provider);
			}
		} catch (SQLException exception) {
			LOGGER.error("error in QueryMapper.SERVICE_LIST");
			throw new IBSExceptions(ExceptionMessages.ERROR11);
		}
		return providers;
	}

	@Override
	public BigDecimal getCurrentBalance(String uci) throws IBSExceptions {
		LOGGER.info("entering into getCurrentBalance method of AutoPaymentDAOImpl class");
		Connection con = ConnectionProvider.getConnection();
		BigDecimal bigDecimal = null;
		try (PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.GET_BALANCE);) {

			preparedStatement.setBigDecimal(1, new BigDecimal(uci));
			try (ResultSet resultSet = preparedStatement.executeQuery();) {
				if (resultSet.next()) {
					bigDecimal = resultSet.getBigDecimal("Current_Balance");
				}
			}
		} catch (SQLException exception) {
			LOGGER.error("error in QueryMapper.GET_BALANCE");
			throw new IBSExceptions(ExceptionMessages.ERROR11);
		}
		return bigDecimal;
	}

	@Override
	public boolean setCurrentBalance(String uci, BigDecimal currentBalnce) throws IBSExceptions {
		LOGGER.info("entering into setCurrentBalance method of AutoPaymentDAOImpl class");
		boolean result = false;
		Connection con = ConnectionProvider.getConnection();
		try (PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.SET_BALANCE);) {
			preparedStatement.setBigDecimal(1, currentBalnce);
			preparedStatement.setBigDecimal(2, new BigDecimal(uci));
			if (preparedStatement.executeUpdate() > 0) {
				result = true;
			}
		} catch (SQLException exception) {
			LOGGER.error("error in QueryMapper.SET_BALANCE");
			throw new IBSExceptions(ExceptionMessages.ERROR11);
		}
		return result;
	}

}
